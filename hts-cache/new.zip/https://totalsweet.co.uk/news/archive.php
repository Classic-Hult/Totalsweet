<!doctype html>
<html itemscope itemtype="http://schema.org/WebPage" lang="en" class="no-js">
    <head>
        <meta charset="utf-8"/>
        <meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />

        <title>Archive</title>

<!-- Basic SEO -->
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="robots" content="" />
<!-- ./Basic SEO -->

<!-- Schema.org -->
<meta itemprop="name" content="Archive">
<meta itemprop="description" content="">
<!-- ./Schema.org -->

<!-- Open Graph -->
<meta property="og:type" content="website" />
<meta property="og:site_name" content="" />


    <meta property="og:title" content="Archive" />



    <meta property="og:description" content="" />

<!-- ./Open Graph -->

<!-- Twitter -->
<meta name="twitter:card" content="summary" />
<meta name="twitter:site" content="">


    <meta name="twitter:title" content="Archive" />



    <meta name="twitter:description" content="" />

<!-- ./Twitter -->



<!-- Schema.org -->
<meta itemprop="image" content="//totalsweet.co.uk/images/meta/meta-logo.png">
<!-- ./Schema.org -->

<!-- Twitter -->
<meta name="twitter:card" content="summary"/>
<meta name="twitter:site" content="">
<meta name="twitter:url" content="//totalsweet.co.uk/news/archive.php"/>
<meta name="twitter:image" content="//totalsweet.co.uk/images/meta/meta-logo.png"/>
<!-- ./Twitter -->

<!-- Open Graph -->
<meta property="og:type" content="website"/>
<meta property="og:site_name" content="Dream Big"/>
<meta property="og:url" content="//totalsweet.co.uk/news/archive.php"/>
<meta property="og:image" content="//totalsweet.co.uk/images/meta/meta-logo.png"/>
<!-- ./Open Graph -->

        <!-- Crawlers -->
        <meta name="rating" content="general"/>
        <meta name="revisit-after" content="1 Month"/>
        <!-- ./Crawlers -->

        <!-- Devices -->
        <meta name="application-name" content="Total Sweet"/>
        <meta name="msapplication-config" content="//totalsweet.co.uk/browserconfig.xml"/>
        <meta name="theme-color" content="#4E97D0">

        <link rel="apple-touch-icon-precomposed" href="//totalsweet.co.uk/images/meta/touch-icon.png"/>
        <link rel="icon" type="image/png" href="//totalsweet.co.uk/images/meta/favicon.png"/>
        <link rel="icon" sizes="152x152" href="//totalsweet.co.uk/images/meta/touch-icon.png">

        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
        <link rel="alternate" type="application/rss+xml" title="RSS" href="//totalsweet.co.uk/news/rss">
        <!-- ./Devices -->

        <!--[if gte IE 9]><!-->
        <link rel="stylesheet" media="screen" href="/css/main.css?v=1655394833"/>
        <!--<![endif]-->

        <!--[if lt IE 9]>
        <script src="/js/html5shiv.js"></script>
        <link rel="stylesheet" media="screen" href="/css/main-ie.css?v=1655394832"/>
        <![endif]-->

        <link rel="stylesheet" media="print" href="/css/print.css?v=1655394833" />

        
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-24900585-1"></script>
        <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        
        gtag('config', 'UA-24900585-1');
        gtag('config', 'AW-1063048448'); // Tag Manager
        </script>
        <!-- ./Google Analytics -->

        <!-- Feature Detection -->
        <script src="/js/modernizr.js"></script>
        <!-- ./Feature Detection -->

        
            </head>

    <body id="csstyle" class="news">

                    <div class="is-static">
        
                <header class="site-header js-sticky">
                    <div class="action-bar">
                        <div class="wrapper">

                            <!-- Primary Nav -->
                            <div class="site-header__primary">
                                <nav class="nav-bar nav-bar--tall nav-bar--divided nav-bar--collapsible">
    <h1 class="nav-bar__logo">
        <a href="/">
            <img
                src="/images/ts-logo.png"
                srcset="/images/ts-logo@2x.png 2x, /images/ts-logo@3x.png 3x"
                alt="Total Sweet" class="ts-logo"
                width="142" height="59"
            />
        </a>
    </h1>
    <ul class="nav-bar__menu js-nav" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
        <li class="nav-bar__page ">
    <a href="/xylitol/" class="nav-link nav-link--reverse " itemprop="url">
        <span itemprop="name">
            Xylitol
        </span>
    </a>
</li>
<li class="nav-bar__page ">
    <a href="/benefits/" class="nav-link nav-link--reverse " itemprop="url">
        <span itemprop="name">
            Benefits
        </span>
    </a>
</li>
<li class="nav-bar__page ">
    <a href="/recipes/" class="nav-link nav-link--reverse " itemprop="url">
        <span itemprop="name">
            Recipes
        </span>
    </a>
</li>
<li class="nav-bar__page ">
    <a href="/diabetes/" class="nav-link nav-link--reverse " itemprop="url">
        <span itemprop="name">
            Diabetes
        </span>
    </a>
</li>
<li class="nav-bar__page ">
    <a href="/news/" class="nav-link nav-link--reverse nav-link--is-active" itemprop="url">
        <span itemprop="name">
            News
        </span>
    </a>
</li>
<li class="nav-bar__page ">
    <a href="/stockists/" class="nav-link nav-link--reverse " itemprop="url">
        <span itemprop="name">
            Stockists
        </span>
    </a>
</li>
<li class="nav-bar__page ">
    <a href="/mixes" class="nav-link nav-link--reverse " itemprop="url">
        <span itemprop="name">
            Mixes
        </span>
    </a>
</li>
    </ul>
</nav>                            </div>
                            <!-- ./Primary Nav -->

                            <!-- Language -->
                            <div class="site-header__control">
                                <a href="#" class="nav-button js-nav-toggle">
    <div class="nav-button__icon">
        <span class="nav-button__bar nav-button__bar--top"></span>
        <span class="nav-button__bar nav-button__bar--ctr-t"></span>
        <span class="nav-button__bar nav-button__bar--ctr-b"></span>
        <span class="nav-button__bar nav-button__bar--btm"></span>
    </div>
    <div class="nav-button__label">
        Menu
    </div>
</a>







<div class="picker js-picker">
    <div class="picker__selected js-picker-toggle">
        <a href="http://totalsweet.co.uk" class="picker__label picker__label--icon-gb">
            <span class="is-desktop">
                United Kingdom
            </span>
            <span class="is-device">
                UK
            </span>
        </a>
    </div>
    <ul class="picker__options">


        










        
        <li class="picker__option">
            <a href="http://totalsweet.eu" class="picker__label picker__label--icon-nl">
                <span class="is-desktop">
                    Netherlands
                </span>
                <span class="is-device">
                    NL
                </span>
            </a>
        </li>
        










        
        <li class="picker__option">
            <a href="http://totalsweet.eu" class="picker__label picker__label--icon-de">
                <span class="is-desktop">
                    Germany
                </span>
                <span class="is-device">
                    DE
                </span>
            </a>
        </li>
        










        
        <li class="picker__option">
            <a href="http://totalsweet.eu" class="picker__label picker__label--icon-fr">
                <span class="is-desktop">
                    France
                </span>
                <span class="is-device">
                    FR
                </span>
            </a>
        </li>
        










        
        <li class="picker__option">
            <a href="http://totalsweet.se" class="picker__label picker__label--icon-se">
                <span class="is-desktop">
                    Sweden
                </span>
                <span class="is-device">
                    SE
                </span>
            </a>
        </li>
        


    </ul>
</div>


                            </div>
                            <!-- ./Language -->

                        </div>
                    </div>

                    <!-- Secondary Navigation -->
<!-- ./Secondary Navigation -->

                </header>

                    </div>
        
    <!-- Archive -->
    <div class="row">
        <div class="wrapper">
            <div class="o-weighted">
                <div class="o-weighted__priority">
                    
    <h1 class="badge badge--title">
        News Archive:
    </h1>
    <ul class="stack stack--divider stack--lg">


        <li class="stack__item">
            <div class="header-post">
                <h1 class="header-post__title">
                    <a href="/news/415-health-risk-associated-with-artifical-sweeteners">
                        Health Risk Associated with Artifical Sweeteners?
                    </a>
                </h1>
                <div class="header-post__meta">
                    <span class="header-post__meta-label">
                        Posted on:
                    </span>
                    04 April 2022
                </div>
            </div>
            
                <p class="isolated">
                    As a new study appears to highlight the health risks associated with artificial sweeteners, what’s the alternative?
                    <a href="/news/415-health-risk-associated-with-artifical-sweeteners" class="arrow">Read more</a>
                </p>
            
        </li>




        <li class="stack__item">
            <div class="header-post">
                <h1 class="header-post__title">
                    <a href="/news/414-balancing-glucose-levels">
                        Balancing Glucose Levels.
                    </a>
                </h1>
                <div class="header-post__meta">
                    <span class="header-post__meta-label">
                        Posted on:
                    </span>
                    21 March 2022
                </div>
            </div>
            
                <p class="isolated">
                    How you can still enjoy carbs and sweet tastes while 
losing weight with Total Sweet®.
                    <a href="/news/414-balancing-glucose-levels" class="arrow">Read more</a>
                </p>
            
        </li>




        <li class="stack__item">
            <div class="header-post">
                <h1 class="header-post__title">
                    <a href="/news/413-did-you-know">
                        Did you know...
                    </a>
                </h1>
                <div class="header-post__meta">
                    <span class="header-post__meta-label">
                        Posted on:
                    </span>
                    03 March 2022
                </div>
            </div>
            
                <p class="isolated">
                    We have a massive back catalogue of downloadable recipes on our website, here is one of our favourites
                    <a href="/news/413-did-you-know" class="arrow">Read more</a>
                </p>
            
        </li>




        <li class="stack__item">
            <div class="header-post">
                <h1 class="header-post__title">
                    <a href="/news/412-national-tree-week">
                        National Tree Week
                    </a>
                </h1>
                <div class="header-post__meta">
                    <span class="header-post__meta-label">
                        Posted on:
                    </span>
                    10 December 2021
                </div>
            </div>
            
                <p class="isolated">
                    Did you know that Total Sweet is made from the bark of sustainably sourced European birch and beech trees?
                    <a href="/news/412-national-tree-week" class="arrow">Read more</a>
                </p>
            
        </li>




        <li class="stack__item">
            <div class="header-post">
                <h1 class="header-post__title">
                    <a href="/news/410-festive-drinks-with-one-wicked-twist">
                        Festive drinks with one wicked twist…
                    </a>
                </h1>
                <div class="header-post__meta">
                    <span class="header-post__meta-label">
                        Posted on:
                    </span>
                    09 December 2021
                </div>
            </div>
            
                <p class="isolated">
                    Ditch high sugar hot drinks, and opt for festive totally sweet alternatives
                    <a href="/news/410-festive-drinks-with-one-wicked-twist" class="arrow">Read more</a>
                </p>
            
        </li>




        <li class="stack__item">
            <div class="header-post">
                <h1 class="header-post__title">
                    <a href="/news/409-when-life-gives-you-lemons">
                        When Life gives you Lemons
                    </a>
                </h1>
                <div class="header-post__meta">
                    <span class="header-post__meta-label">
                        Posted on:
                    </span>
                    07 December 2021
                </div>
            </div>
            
                <p class="isolated">
                    The humble lemon makes the ‘diabetic superfoods’ list.  Here is how Total Sweet is the perfect partner...
                    <a href="/news/409-when-life-gives-you-lemons" class="arrow">Read more</a>
                </p>
            
        </li>


    </ul>
    
        <nav class="paging">
            

            <div class="paging__label">
                Page 1 of 40
            </div>

            
            <div class="paging__next">
                <a href="/news/archive.php?page=2" class="button button--sm">
                    Next &raquo;
                </a>
            </div>
            
        </nav>
    

                </div>
            </div>
        </div>
    </div>
    <!-- ./Archive -->

        <!-- Site Footer -->
        <footer class="site-footer row row--dark row--narrow">
            <div class="wrapper">
                <!-- Footer Navigation -->
                <nav class="nav-bar nav-bar--divided">
    <strong class="nav-bar__logo nav-bar__logo--sm">
        <a href="/">
            <img
                src="/images/ts-logo--reversed.png"
                srcset="/images/ts-logo--reversed@2x.png 2x, /images/ts-logo--reversed@3x.png 3x"
                alt="Total Sweet" class="ts-logo"
                width="93" height="37"
            />
        </a>
    </strong>
    <ul class="nav-bar__menu" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
        <li class="nav-bar__page">
    <a href="/privacy-and-terms-conditions" class="nav-link nav-link--sm nav-link--reverse " itemprop="url">
        <span itemprop="name">
            Terms &amp; privacy
        </span>
    </a>
</li>
<li class="nav-bar__page">
    <a href="/study" class="nav-link nav-link--sm nav-link--reverse " itemprop="url">
        <span itemprop="name">
            Studies of interest
        </span>
    </a>
</li>
<li class="nav-bar__page">
    <a href="/xylitol/about" class="nav-link nav-link--sm nav-link--reverse " itemprop="url">
        <span itemprop="name">
            About us
        </span>
    </a>
</li>
<li class="nav-bar__page">
    <a href="/contact-us" class="nav-link nav-link--sm nav-link--reverse " itemprop="url">
        <span itemprop="name">
            Contact us
        </span>
    </a>
</li>
<li class="nav-bar__page">
    <a href="/xylitol/faqs" class="nav-link nav-link--sm nav-link--reverse " itemprop="url">
        <span itemprop="name">
            FAQs
        </span>
    </a>
</li>
    </ul>
</nav>
                <!-- ./Footer Navigation -->

                <!-- Connections -->
                <div class="site-footer__connections">
    
        <a href="https://facebook.com/TotalSweetXylitol" target="_blank" class="icon icon--xs icon--hoverable icon--facebook +hover-bounce">
        Facebook
        </a>
    

    
        <a href="https://instagram.com/TotalSweetXylitol" target="_blank" class="icon icon--xs icon--hoverable icon--instagram +hover-bounce">
        Instagram
        </a>
    
</div>
                <!-- ./Connections -->

                <!-- Package -->
                <div class="site-footer__package">
                    <img src="/images/graphics/footer-package.png" alt="Packaging" />
                </div>
                <!-- ./Package -->
            </div>
        </footer>
        <!-- ./Site Footer -->

        <!-- Scripts -->
                <script data-main="/js/main.js?v=1655394850" src="/js/vendor/require.js"></script>

        <script src="https://www.google.com/recaptcha/api.js?render=6LcStukUAAAAADjFtZOvDEUidVtwAQCallQWmOf1"></script>
                <script>
                grecaptcha.ready(function() {
                                            // do request for recaptcha token
                                            // response is promise with passed token
                                            grecaptcha.execute('6LcStukUAAAAADjFtZOvDEUidVtwAQCallQWmOf1', {action:'root_validate_captcha'})
                                                      .then(function(token) {
                                                          var response = document.querySelector('input[name="gresponse"]');
                                                          response.value = token;
                                                      });
                                        });
                </script>                <!-- ./Scripts -->

        
            </body>
</html>

